function rentalDays(date1, date2) {
  // Convert both dates to milliseconds since epoch
  const date1Ms = new Date(date1).getTime();
  const date2Ms = new Date(date2).getTime();

  // Calculate the difference in milliseconds
  const differenceMs = Math.abs(date2Ms - date1Ms);

  // Convert the difference from milliseconds to days
  // 1000 ms * 60 sec * 60 min * 24 hours = 86400000 ms in a day
  const daysDifference = Math.floor(differenceMs / (1000 * 60 * 60 * 24));

  return daysDifference;
}

// Example usage
// const startDate = '2025-04-01';
// const endDate = '2025-04-05';
// console.log(`Days between: ${daysBetweenDates(startDate, endDate)}`); // Output: 4

function calculateRentalPrice(groupCode, PickupDate, dropOffDate) {
  // Define the price per day for each group code
  if (groupCode == "F") {
    return rentalDays(PickupDate, dropOffDate) * 40;
  } else if (groupCode == "I") {
    return rentalDays(PickupDate, dropOffDate) * 30;
  } else if (groupCode == "E") {
    return rentalDays(PickupDate, dropOffDate) * 20;
  }
}

function carCategoryMapper(groupCode) {
  if (groupCode == "F") {
    return 4;
  } else if (groupCode == "I") {
    return 3;
  } else if (groupCode == "E") {
    return 2;
  }
}

function carCategoryName(groupCode) {
  if (groupCode == "F") {
    return "Full Size or 7 seater";
  } else if (groupCode == "I") {
    return "Intermediate or 5 seater";
  } else if (groupCode == "E") {
    return "Compact or 4 seater";
  }
}

module.exports = {
  rentalDays,
  calculateRentalPrice,
  carCategoryMapper,
  carCategoryName,
};
